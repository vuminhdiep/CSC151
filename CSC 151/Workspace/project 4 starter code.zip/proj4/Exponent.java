package proj4;

/**
 * Write a description of class Exponent here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Exponent {    
   
}
