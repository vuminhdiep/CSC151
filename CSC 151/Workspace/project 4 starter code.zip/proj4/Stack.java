package proj4;

// Don't forget the Javadocs!
// Notice that the generic type parameter does NOT implement
// the Token interface.  Make sure you understand why it shouldn't
// (and see the StackTest class for a hint.  Or just ask me!)
public class Stack<T>
{
    
    public Stack() {
       
    }
   
    public boolean isEmpty() {  
    	return true;  //erase this line  
    }

    public void push(T toPush) {
       
    }
  
    public T pop() {
    	return null;  //erase this line
    } 
  
    public T peek() {
    	return null;  //erase this line
    } 
    
    public int size() {
    	return -1;    //erase this line
    }
     
    public String toString() {
        return "";    //erase this line
    }
    
} 
   

